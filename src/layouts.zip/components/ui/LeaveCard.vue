<template>
  <div class="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
    <slot />
  </div>
</template>

<script setup lang="ts">
// LeaveCard component
</script>
